module.exports = {
    ServerID: "",
    ServerURL: "ertu",
    BotStatus: ["Ertu ❤️ V14","Ertu Was Here"],
    BotVoiceChannel: "",
    SubTitle: "Ertu was here ❤️",
    BackGround: "https://cdn.discordapp.com/attachments/930486300639891466/1103290225750450196/pexels-eberhard-grossgasteiger-1421903.jpg",
    
    MongoURL: "",
    BotOwner: ["136619876407050240","797096076330795018","341592492224806914","952214954931544164","719117042904727635","587564522009788426"],

    Moderation: {
    Token: "",

    EmojiNumbers: false,
    GlobalInteractions: true,

    dmMessages: true,
    LevelSystem: true,
  
    messageDolar: 1,
    voiceDolar: 1,
  
    messageCount: 1,
    messageCoin: 2,
    voiceCount: 1,
    voiceCoin: 4,
    publicCoin: 4,
    inviteCount: 1,
    inviteCoin: 15,
    taggedCoin: 25,
    toplamsCoin: 5.5,
    yetkiCoin: 30,
    fakeDay: 7,
  
    banlimit: 3,
    jaillimit: 3,
    warnlimit: 3,
    chatmutelimit: 3,
    voicemutelimit: 3,

        Prefixs: [
            ".",
            "+",
            "!",
            "/",
            "-",
            "?",
            "="
        ]
    }
}